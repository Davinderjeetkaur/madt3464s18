import Foundation 

print("Hello World")
var range = 1...100
print(range)
print(range.contains(50))
print("Lowerbound",range.lowerBound)
print("Upperbound",range.upperBound)

var day = "Today is Monday"
print("Today is Monday")
 
//var string = "Monday is today"
//string.reverse("Monday is today")
//print(reverse)
var davinder = """
hye how are you? 
i am good
"""

davinder += "  what are u doing"
davinder.append(" nothing")
print(davinder)  

let str = "davinder"
print(String(str.reversed()))

//var vowels = (a)

//switch vowels{
    case (a,e,i,o,u):
    print("vowels")
    default:
    print("consonent")
//}
func vowelConsonants( vowels: Int, consonants: Int){
let vowels = "aeiou".characters
let consonants = "bcdfghjklmnpqrstvwxyz".characters
var vowelCount = 0
var consonantCount = 0

for letter in lowecased().characters{
if vowels.contains(letter){
    vowelCount += 1
}else{
    if consonants.contains(letter){
        consonantCount += 1
    }
}
}
    return(vowelCount,consonantCount)
}
print(vowelConsonants("hello"))





