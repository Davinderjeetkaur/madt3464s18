//
//  Extension.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-08-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//extension Date{
// let dateCurrent = Date(){
//print("Date 1 : \(dateCurrent)")
//var date: String{
//    let dateString = "12/01/2003"
//let dateFormatter = DateFormatter()
//dateFormatter.dateFormat = "MM/dd/yyyy"
//let dateFromString = dateFormatter.date(from: dateString)
//print("Date : \(dateFromString!)")
// //   return dateString.string(for: self)!
//    }
