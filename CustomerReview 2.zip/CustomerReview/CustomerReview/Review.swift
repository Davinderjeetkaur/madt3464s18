//
//  Review.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-15.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class Review: UIViewController {


    @IBOutlet weak var ratingStackView: UIStackView!
    @IBOutlet weak var txtComments: UITextField!
    @IBOutlet weak var pickCategory: UIPickerView!
    @IBOutlet weak var txtPlaceName: UITextField!
    @IBAction func btnSubmit(_ sender: Any) {
    }
    
    let categoryList : [String] = ["Restaurents", "Hotels", "Tourist Attraction"]
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "TableVC"
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayInfo))
//        self.navigationItem.rightBarButtonItem = btnSubmit
    
        @objc func displayInfo(){
            var userInfo : String = txtComments.text!
            userInfo += "\n" + txtPlaceName.text!
         
            
            userInfo += "\n \(categoryList[pickCategory.selectedRow(inComponent: 0)])"
            
        
        
        
        
        
        func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

        func btnClicked(_ sender: UIButton) {
      
            
        }
    
        func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
