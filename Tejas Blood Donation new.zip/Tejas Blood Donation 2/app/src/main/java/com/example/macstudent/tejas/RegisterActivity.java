package com.example.macstudent.tejas;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnRegister;
    EditText edtName;
    EditText edtPhone;
    EditText edtEmail;
    EditText edtPassword;
    RadioButton rdoMale,rdoFemale;
    TextView txtBloodDonation;



    DBHelper dbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnRegister = findViewById(R.id.btnRegister);
        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        txtBloodDonation = findViewById(R.id.txtBloodDonation);
        txtBloodDonation.setOnClickListener(this);

        rdoMale = findViewById(R.id.rdoMale);
        rdoMale.setOnClickListener(this);

        rdoFemale = findViewById(R.id.rdoFemale);
        rdoFemale.setOnClickListener(this);

        btnRegister.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    public void onClick(View v)
    {
        if (v.getId() == btnRegister.getId())
        {
           String data = edtName.getText().toString() + "\n" + edtPhone.getText().toString() + "\n" + edtEmail.getText().toString()
                 + edtPassword.getText().toString();

          Toast.makeText(this, data, Toast.LENGTH_LONG).show();

            insertData();
            displayData();

            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
    //    else if (v.getId() == txtDOB.getId())
    //    {
    //        Calendar calendar = Calendar.getInstance();
    //        new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR),
    //                calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
    //    }
   // }
   // DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
   //     @Override
   //     public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
   //         String date = String.valueOf(month+1) + "/" + String.valueOf(dayOfMonth) + "/" + String.valueOf(year);
   //         txtDOB.setText(date);
    //    }
    };
    private void insertData()
    {
        try {
            ContentValues cv = new ContentValues();
            cv.put("Name",edtName.getText().toString());
            cv.put("Phone" ,edtPhone.getText().toString());
            cv.put("Email" ,edtEmail.getText().toString());
            cv.put("Password" ,edtPassword.getText().toString());
          cv.put("BloodDonation",txtBloodDonation.getText().toString());

            db = dbHelper.getWritableDatabase();
            db.insert("UserInfo" , null, cv);

            Log.v("RegisterActivity" , "User Account Created");
        }
        catch (Exception e)
        {
            Log.e("RegisterActivity" , e.getMessage());
        }
        finally
        {
            db.close();
        }
    }
    private void displayData()
    {
        try {
            db = dbHelper.getReadableDatabase();
            String columns[] = {"Name" , "Phone" , "Email" , "Password"};

            Cursor cursor = db.query("UserInfo" , columns, null, null, null, null, null);

            while (cursor.moveToNext())
            {
                String userdata = cursor.getString(cursor.getColumnIndex("Name"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Phone"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("BloodDonation"));

                Toast.makeText(this, userdata, Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            Log.e("RegisterActivity" , e.getMessage());
        }
        finally {
            db.close();
        }
    }
}
