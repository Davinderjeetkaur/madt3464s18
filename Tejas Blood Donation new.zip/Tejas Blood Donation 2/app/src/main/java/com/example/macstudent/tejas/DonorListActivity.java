package com.example.macstudent.tejas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class DonorListActivity extends AppCompatActivity implements   View.OnClickListener, AdapterView.OnItemSelectedListener {

    TextView txtBloodGroup;
    TextView txtBlood;
    Button btnAddDonor;
    RadioButton rdoAPositive, rdoANegative, rdoBPositive, rdoBNegative, rdoABPositive, rdoABNegative, rdoOPositive,
            rdoONegative;

    String DonorNames[] = {"Ramesh , Navdeep, Aman", "Suresh, Gurpreet, Tejas", "Nitesh, Charles, Davinder", "Kamlesh, Sukhwinder, Simran", "Duresh, Narinder","David, Arsh, John","Robert, Suman","Mark, Raman" };

    // Spinner spnBloodGroup;
    //   Button btnAddDonor;
    //   String[] bloodgroups = {"A+" , "A-" , "B+" , "B-" , "O+" , "O-" , "AB+" , "AB-"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_list);

        txtBlood = findViewById(R.id.txtBlood);
        txtBlood.setText(DonorNames[0]);

        btnAddDonor = findViewById(R.id.btnAddDonor);
        btnAddDonor.setOnClickListener(this);

        rdoAPositive = findViewById(R.id.rdoAPositive);
        rdoAPositive.setOnClickListener(this);

        rdoANegative = findViewById(R.id.rdoANegative);
        rdoANegative.setOnClickListener(this);

        rdoBPositive = findViewById(R.id.rdoBPositive);
        rdoBPositive.setOnClickListener(this);

        rdoBNegative = findViewById(R.id.rdoBNegative);
        rdoBNegative.setOnClickListener(this);

        rdoABPositive = findViewById(R.id.rdoABPositive);
        rdoABPositive.setOnClickListener(this);

        rdoABNegative = findViewById(R.id.rdoABNegative);
        rdoABNegative.setOnClickListener(this);

        rdoOPositive = findViewById(R.id.rdoOPositive);
        rdoOPositive.setOnClickListener(this);

        rdoONegative = findViewById(R.id.rdoONegative);
        rdoONegative.setOnClickListener(this);

        //       spnBloodGroup = findViewById(R.id.spnBloodGroup);
        //     ArrayAdapter bloodGroupAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,                //        bloodgroups);
        //  spnBloodGroup.setAdapter(bloodGroupAdapter);
        //  spnBloodGroup.setOnItemSelectedListener(this);


    }

    @Override
    public void onClick(View view) {

        if (view.getId() == rdoAPositive.getId())
        {
            txtBlood.setText(DonorNames[0]);
        }
        else if (view.getId() == rdoANegative.getId())
        {
            txtBlood.setText(DonorNames[1]);
        }
        else if(view.getId() == rdoABPositive.getId())
        {
            txtBlood.setText(DonorNames[2]);
        }
        else if(view.getId() == rdoABNegative.getId())
        {
            txtBlood.setText(DonorNames[3]);
        }
        else if(view.getId() == rdoBPositive.getId())
        {
            txtBlood.setText(DonorNames[4]);
        }
        else if(view.getId() == rdoBNegative.getId())
        {
            txtBlood.setText(DonorNames[5]);
        }
        else if(view.getId() == rdoOPositive.getId())
        {
            txtBlood.setText(DonorNames[6]);
        }
        else if(view.getId() == rdoONegative.getId())
        {
            txtBlood.setText(DonorNames[7]);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}

