//
//  DescriptionCell.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class DescriptionCell: UITableViewCell {
    @IBOutlet weak var imgtitle: UIImageView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
}
