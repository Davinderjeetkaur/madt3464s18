//
//  GPACal_AppDelegate.h
//  GPACal
//
//  Created by Andrew Robinson on 4/18/14.
//  Copyright (c) 2014 Andrew Robinson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GPACal_AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
