//
//  GPACal_AboutViewController.h
//  GPACal
//
//  Created by Andrew Robinson on 4/28/14.
//  Copyright (c) 2014 Andrew Robinson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GPACal_GPAItem.h"

@interface GPACal_AboutViewController : UIViewController

@property GPACal_GPAItem *GPAItem;

@end
