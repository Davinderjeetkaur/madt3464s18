//
//  GPACal_AddGPAItemViewController.h
//  GPACal
//
//  Created by Andrew Robinson on 4/19/14.
//  Copyright (c) 2014 Andrew Robinson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GPACal_GPAItem.h"

@interface GPACal_AddGPAItemViewController : UIViewController

@property GPACal_GPAItem *GPAItem;

@end
