 //
//  main.m
//  GPACal
//
//  Created by Andrew Robinson on 4/18/14.
//  Copyright (c) 2014 Andrew Robinson. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GPACal_AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GPACal_AppDelegate class]));
    }
}
