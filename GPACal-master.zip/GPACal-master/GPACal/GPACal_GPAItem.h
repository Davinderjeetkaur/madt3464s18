//
//  GPACal_GPAItem.h
//  GPACal
//
//  Created by Andrew Robinson on 4/19/14.
//  Copyright (c) 2014 Andrew Robinson. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GPACal_GPAItem : NSObject

@property NSString *className;
@property NSNumber *credit;
@property NSString *grade;
@property NSNumber *gpa;

@end
