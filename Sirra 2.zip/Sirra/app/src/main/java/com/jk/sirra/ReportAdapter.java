package com.jk.sirra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;

    String[]  carplates = {"ABCD1234" , "ASDF211" , "JKL191"};
    String[] amount = {"$10", "$20" , "$30"};
    String[] lots = {"A", "J","P"};
    String[] spots = {"101", "10","23"};
    String[] dateTime = {"06-27-2018 12.30 PM" , "06-27-2018 1.30 PM" , "06-27-2018 3.30 PM"};



    ReportAdapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(context);
    }




    @Override
    public int getCount() {

        return carplates.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {

        view = inflater.inflate(R.layout.list_report_item,null);

        TextView txtCarPlate = view.findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(carplates[position]);

        TextView txtAmount = view.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + amount[position]);

        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);

        TextView txtLot = view.findViewById(R.id.txtLot);
        txtLot.setText("Lot: " + lots [position]);

        TextView txtSpot = view.findViewById(R.id.txtSpot);
        txtSpot.setText("Spot:  " + spots    [position]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Item" + position +"selected" , Toast.LENGTH_SHORT).show();
            }
        });
        return null;
    }
}
