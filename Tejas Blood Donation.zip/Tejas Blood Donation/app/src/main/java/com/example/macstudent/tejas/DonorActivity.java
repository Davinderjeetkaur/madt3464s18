package com.example.macstudent.tejas;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DonorActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edtName, edtBloodgroup, edtEmail, edtContact;
    Button btnSubmit;

    DBHelper dbHelper;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor);

        edtName = findViewById(R.id.edtName);
        edtBloodgroup = findViewById(R.id.edtBloodgroup);
        edtEmail = findViewById(R.id.edtEmail);
        edtContact = findViewById(R.id.edtContact);

        btnSubmit.setOnClickListener(this);
        dbHelper = new DBHelper(this);



    }

    public void onClick(View v) {
        if (v.getId() == btnSubmit.getId()) {
            String data = edtName.getText().toString() + "\n" + edtBloodgroup.getText().toString() + "\n" + edtEmail.getText().toString()
                    + edtContact.getText().toString();

            Toast.makeText(this, data, Toast.LENGTH_LONG).show();

            insertData();
            displayData();

            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
    }
        private void insertData () {
            try {
                ContentValues cv = new ContentValues();
                cv.put("Name",edtName.getText().toString());
                cv.put("Bloodgroup" ,edtBloodgroup.getText().toString());
                cv.put("Email" ,edtEmail.getText().toString());
                cv.put("Contact" ,edtContact.getText().toString());


                db = dbHelper.getWritableDatabase();
                db.insert("UserInfo" , null, cv);

                Log.v("DonorActivity" , "User Account Created");
            }
            catch (Exception e)
            {
                Log.e("DonorActivity" , e.getMessage());
            }
            finally
            {
                db.close();
            }
        }


    private void displayData() {
        try {
            db = dbHelper.getReadableDatabase();
            String columns[] = {"Name" , "Phone" , "Email" , "Password"};

            Cursor cursor = db.query("UserInfo" , columns, null, null, null, null, null);

            while (cursor.moveToNext())
            {
                String userdata = cursor.getString(cursor.getColumnIndex("Name"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Bloodgroup"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                userdata += "\n" + cursor.getString(cursor.getColumnIndex("Contact"));


                Toast.makeText(this, userdata, Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            Log.e("DonorActivity" , e.getMessage());
        }
        finally {
            db.close();
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}